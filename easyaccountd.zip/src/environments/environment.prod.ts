export const environment = {
  production: true,
  verssion: 'v1/',
  // baseUrl:  'http://10.0.38.24:81/easyAccount/api/',
  // baseUrl2:  'http://10.0.38.24:81/api/',
  // login : 'http://10.0.38.24:81/easyAccount/api/v1/session/user-login',
  // login2 : 'http://10.0.38.24:81/easyAccount/api/v1/session/user-login',
  // signup : 'http://10.0.38.24:81/api/signup',

  baseUrl:  'http://10.0.33.122:81/easyAccount/api/',
  baseUrl2:  'http://10.0.33.122:81/api/',
  login : 'http://10.0.33.122:81/easyAccount/api/v1/session/user-login',
  login2 : 'http://10.0.33.122:81/easyAccount/api/v1/session/user-login',
  signup : 'http://10.0.33.122:81/api/signup',
  commonAPI: 'http://10.0.33.12:8017/',
};
