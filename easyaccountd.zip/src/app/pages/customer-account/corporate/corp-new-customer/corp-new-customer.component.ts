import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corp-new-customer',
  templateUrl: './corp-new-customer.component.html',
  styleUrls: ['./corp-new-customer.component.css']
})
export class CorpNewCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
