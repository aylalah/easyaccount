import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { debounceTime, map, switchMap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { JarwisService } from 'src/app/Services/jarwis.service';
import { CustomerAccountService } from 'src/app/Services/customer-account.service';
import { TokenService } from 'src/app/Services/token.service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzSelectSizeType } from 'ng-zorro-antd/select';

@Component({
  selector: 'app-pre-generated',
  templateUrl: './pre-generated.component.html',
  styleUrls: ['./pre-generated.component.css']
})
export class PreGeneratedComponent implements OnInit {

  public form = {
    accountType: null,
    numberOfAccounts: null,
    SchemeType: null,
    SchemeCode: null,
    staffId: null,
}
  disabled: boolean;
  response: any;
  resMessage: any;
  users: any;
  responsecode: any;
  error: any;
  success: any;
  shemeTypes: any;
  shemecodes: any;
  selectedUser?: string;
  isLoading = false;
  profResponds: any;
  me: any;
  myId: any;
  type: string;
  isSuccess: any;
  batchNumber: any;

  current = 0;

  index = 'First-content';
  visible2: boolean;
  visible: boolean;
  showsDetails: boolean;
  isLoading2 = false;

  constructor(
    private Jarwis: JarwisService,
    private http: HttpClient,
    private customerAccount: CustomerAccountService,
    private Token: TokenService,
    private router: Router,
    private Auth: AuthService,
    private nzMessageService: NzMessageService,
    private notification: NzNotificationService,
  ) { }

  ngOnInit(): void {
    this.isLoading = true;

    this.Jarwis.myProfile().subscribe(
      data => {
        this.profResponds = data;
        this.me = this.profResponds;
        this.myId = this.me.emp_id;
        this.form.staffId = this.myId;
      }
    );

    this.customerAccount.SchemeTypes().subscribe(
      data => { this.isLoading = false;
                const allSchemTpes: any = data;
                this.shemeTypes = allSchemTpes;
      },
      error => {}
    );
  }
  onSelectSchemeTypes(val): void {
    this.isLoading2 = true;
    const getSchemeType: any =  val;
    this.customerAccount.SchemeCodes(getSchemeType).subscribe(
      data => {
                this.isLoading2 = false;
                const allSchemCode: any = data;
                this.shemecodes = allSchemCode;
      },
      error => this.handleError(error)
    );
  }

  onSubmit(): void{
    this.disabled = true;
    this.form.staffId = this.myId;
    this.customerAccount.PREGeneration(this.form).subscribe(
      data => this.handleResponse(data),
      error => this.handleError(error)
    );
  }

  handleResponse(data): void{
    this.disabled = false;
    this.responsecode = data.responseCode;
    this.isSuccess = data.isSuccess;
    this.batchNumber =  data.batchNumber;


    console.log(this.responsecode);
    console.log(this.isSuccess);
    console.log(this.batchNumber);

    this.current += 1;
    this.changeContent();


    if (this.isSuccess === true) {
      this.type = 'success';
      this.notification.create(
        this.type,
        'Operation successfull',
        'Batch Number Generated'
      );
    }
  }
  handleError(error): void{
    this.disabled = false;
    this.responsecode = error.error.ResponseCode;
    this.response = error.error.ErrorResponse;

    if (this.responsecode == 3) {
      this.type = 'error';
      this.notification.create(
        this.type,
        this.resMessage,
        this.response
      );
    }

    if (this.responsecode != 3) {
      this.type = 'error';
      this.notification.create(
        this.type,
        'Operation not successfull',
        'Something on usual went wrong'
      );
    }
  }





  pre(): void {
    this.current -= 1;
    this.changeContent();
  }

  next(): void {
    this.current += 1;
    this.changeContent();
  }

  done(): void {
    console.log('done');
  }

  changeContent(): void {
    switch (this.current) {
      case 0: {
        this.index = 'First-content';
        break;
      }
      case 1: {
        this.index = 'Second-content';
        break;
      }
      case 2: {
        this.index = 'third-content';
        break;
      }
      default: {
        this.index = 'error';
      }
    }
  }

  close(): void {
    this.visible = false;

    this.form.accountType = '';
    this.form.numberOfAccounts = '';
    this.form.SchemeType = '';
    this.form.SchemeCode = '';
    this.form.staffId = '';

    this.current = 0;
    this.changeContent();
  }
  again(): void{

    this.form.accountType = '';
    this.form.numberOfAccounts = '';
    this.form.SchemeType = '';
    this.form.SchemeCode = '';
    this.form.staffId = '';

    this.current = 0;
    this.changeContent();
  }

}
