import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { JarwisService } from 'src/app/Services/jarwis.service';
import { TokenService } from 'src/app/Services/token.service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzUploadFile } from 'ng-zorro-antd/upload';
import { NzUploadChangeParam } from 'ng-zorro-antd/upload';
import { CustomerAccountService } from 'src/app/Services/customer-account.service';
// import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
// import { NzFormTooltipIcon } from 'ng-zorro-antd/form';
// import { NzFormModule } from 'ng-zorro-antd/form';

declare let $: any;

@Component({
  selector: 'app-new-customer',
  templateUrl: './new-customer.component.html',
  styleUrls: ['./new-customer.component.css']
})
export class NewCustomerComponent implements OnInit {
  current = 0;
  index = 'First-content';
  image: string | ArrayBuffer;
  img: string | ArrayBuffer;
  disabled: boolean;
  disabled2= false;
  response: any;
  resMessage: any;
  users: any;
  responsecode: any;
  success: any;

  public form = {

    Email: '',
    Salutation: '',
    Gender: '',
    Address: '',
    MaritalStatus: '',
    BVN: '',
    Manager: '',
    firstname: '',
    lastname: '',
    dob: '',
    phone: '',
    bvn: '',
  };
  loadDetails: boolean;
  error: string;
  visible: boolean;
  bvnResponse: any;
  BvnDetails: any;
  resTittle: any;
  errorResponse: any;
  showsDetails: boolean;
  type: string;
  profResponds: any;
  me: any;
  myId: any;
  disableSubmitBotton = true;
  BvnDetails2: any;
  resMessage2: any;
  responsecode2: any;
  response2: any;
  disabled3: boolean;
  showsDetails3 = false;

  constructor(
    private Jarwis: JarwisService,
    private Token: TokenService,
    private router: Router,
    private Auth: AuthService,
    private nzMessageService: NzMessageService,
    private msg: NzMessageService,
    private notification: NzNotificationService,
    private customerAccount: CustomerAccountService,
    // private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    this.showsDetails = false;

    this.Jarwis.myProfile().subscribe(
      data => {
        this.profResponds = data;
        this.me = this.profResponds;
        this.myId = this.me.emp_id;
      }
    );

  }

  pre(): void {
    this.current -= 1;
    this.changeContent();
  }

  next(): void {
    this.current += 1;
    this.changeContent();
  }

  done(): void {
    this.disableSubmitBotton = true;
    console.log('done');
  }

  close(): void {
    this.visible = false;

    this.form  = {

      Email: '',
      Salutation: '',
      Gender: '',
      Address: '',
      MaritalStatus: '',
      BVN: '',
      Manager: '',
      firstname: '',
      lastname: '',
      dob: '',
      phone: '',
      bvn: '',
    };
    this.error = '';
    this.disableSubmitBotton = true;
    this.current = 0;
    this.changeContent();
  }
  again(): void{
    this.form  = {

      Email: '',
      Salutation: '',
      Gender: '',
      Address: '',
      MaritalStatus: '',
      BVN: '',
      Manager: '',
      firstname: '',
      lastname: '',
      dob: '',
      phone: '',
      bvn: '',
    };
    this.error = '';
    this.disableSubmitBotton = true;
    this.current = 0;
    this.changeContent();
  }

  onGo(): void{
    this.disabled = true;
    this.loadDetails = true;
    if (this.form.BVN == null) {
      this.error = 'Empty field, Please inpute the Customer BVN';
      this.disabled = false;
      this.loadDetails = false;
    } else {

      this.customerAccount.BvnValidation(this.form.BVN).subscribe(
        data => {
          this.disabled = false;
          this.bvnResponse = data;
          this.BvnDetails = this.bvnResponse.bvnDetails;
          this.resMessage = this.BvnDetails.responseMessage;
          this.resTittle = this.bvnResponse.Message;
          this.errorResponse = this.bvnResponse.isSuccess;
          this.loadDetails = false;
          // this.success = this.admessage;
          this.form.Email = this.BvnDetails.email;
          this.form.firstname = this.BvnDetails.firstName;
          this.form.lastname = this.BvnDetails.lastName;
          this.form.dob = this.BvnDetails.dateOfBirth;
          this.form.phone = this.BvnDetails.phoneNumber;
          this.showsDetails = true;

          if (this.errorResponse === false) {
            this.type = 'success';
            this.notification.create(
              this.type,
              this.resTittle,
              this.resMessage,
            );

            this.current = 1;
            this.changeContent();
          }
        },
        error => {
          this.error = 'Invalid credentials';
          this.loadDetails = false;
          this.disabled = false;
          this.responsecode = error.error.ResponseCode;
          this.response = error.error.ErrorResponse;
          this.resMessage = error.error.Message;

          if (this.responsecode != 0) {
            this.type = 'error';
            this.notification.create(
              this.type,
              this.resMessage,
              this.response,
            );
          }
        },
      );

    }
  }

  changeContent(): void {
    switch (this.current) {
      case 0: {
        this.index = 'First-content';
        break;
      }
      case 1: {
        this.index = 'Second-content';
        break;
      }
      case 2: {
        this.index = 'third-content';
        break;
      }
      case 3: {
        this.index = 'fourth-content';
        break;
      }
      default: {
        this.index = 'error';
      }
    }
  }

  onCheckValidation(): void{

    if (this.form.Salutation == '' || this.form.Gender == '' ||
        this.form.Address == '' || this.form.MaritalStatus == '' || this.form.BVN == '') {

          this.disableSubmitBotton = true;

    } else {
      this.disableSubmitBotton = false;

    }

  }

  notValidForm(){
    this.type = 'warning';
    this.notification.create(
      this.type,
      'Oops',
      'Some required feild are empty, Please preview and check'
    );
  }


  onGoParentCif(): void{
    this.disabled2 = true;
    this.loadDetails = true;
    if (this.form.Manager == '') {
      this.error = 'Empty field, Please inpute the Customer BVN';
      this.disabled = false;
      this.loadDetails = false;
      this.disabled2 = false;
    } else {

      this.customerAccount.getRmCode(this.form.Manager).subscribe(
        data => {
          this.disabled2 = false;
          this.bvnResponse = data;
          this.BvnDetails2 = this.bvnResponse.rmDetails;
          this.resMessage2 = this.bvnResponse.responseMessage;
          // this.resTittle = this.bvnResponse.Message;
          this.responsecode2 = this.bvnResponse.responseCode;
          this.loadDetails = false;
          this.showsDetails3 = true;

          if (this.responsecode2 === '0') {
            this.type = 'success';
            this.notification.create(
              this.type,
              this.resMessage2,
              'Valid RM Code',
            );
            this.error = '';
          }
        },
        error => {
          this.error = 'Invalid credentials';
          this.loadDetails = false;
          this.disabled2 = false;
          this.showsDetails = false;
          this.responsecode2 = error.error.responseCode;
          this.response2 = error.error.ErrorResponse;
          this.resMessage2 = error.error.responseMessage;

          if (this.responsecode !== 0) {
            this.type = 'error';
            this.notification.create(
              this.type,
              this.resMessage2,
              this.response2,
            );
          }
        },
      );

    }
    this.onCheckValidation();
  }



  onSubmit(): void{
    this.disabled = true;
    this.loadDetails = true;
    // this.form.Manager = this.myId;
    this.form.bvn = this.form.BVN;
    if (this.form.Gender == null) {
      this.error = 'Empty field, Please inpute the user A.D';
      this.disabled = false;
      this.loadDetails = false;
    } else {
      console.log(this.form);
      this.customerAccount.CreateCustomer(this.form).subscribe(
      data => this.handleResponse(data),
      error => this.handleError(error)
    );
  }
  }

  handleResponse(data): void{
    this.disabled = false;
    this.disableSubmitBotton = true;
    this.current += 1;
    this.changeContent();

    this.responsecode = data.responseCode;
    this.resMessage = data.errorResponse;
    this.errorResponse = data.isSuccess;
    if (this.errorResponse === true) {
      this.type = 'true';
      this.notification.create(
        this.type,
        'operation Successful',
        'Customer Created Successfully',
      );
    }

  }

  handleError(error): void{
    this.disabled = false;
    this.responsecode = error.error.ResponseCode;
    this.response = error.error.ErrorResponse;
    this.current += 1;
    this.changeContent();

  }

}
