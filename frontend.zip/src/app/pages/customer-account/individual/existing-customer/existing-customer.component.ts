import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-existing-customer',
  templateUrl: './existing-customer.component.html',
  styleUrls: ['./existing-customer.component.css']
})
export class ExistingCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
