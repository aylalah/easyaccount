import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-individual',
  templateUrl: './individual.component.html',
  styleUrls: ['./individual.component.css']
})
export class IndividualComponent implements OnInit {

  account = 'new';
  constructor() { }

  ngOnInit(): void {
  }

  swichAccount(val): void{
    if (val === 'new') {
      this.account = 'new';
    } else if (val === 'existing'){
      this.account = 'existing';
    }
  }

}
