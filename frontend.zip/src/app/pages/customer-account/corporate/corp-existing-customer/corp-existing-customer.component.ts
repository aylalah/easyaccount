import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corp-existing-customer',
  templateUrl: './corp-existing-customer.component.html',
  styleUrls: ['./corp-existing-customer.component.css']
})
export class CorpExistingCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
